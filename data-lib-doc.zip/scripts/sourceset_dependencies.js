sourceset_dependencies = '{":data-lib:dokkaHtml/main": []}'
